export default {
  'component.tagSelect.expand': 'Expandir',
  'component.tagSelect.collapse': 'Contraer',
  'component.tagSelect.all': 'Todos',
};
