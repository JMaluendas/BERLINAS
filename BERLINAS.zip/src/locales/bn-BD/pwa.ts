export default {
  'app.pwa.offline': 'Actualmente estás fuera de línea',
  'app.pwa.serviceworker.updated': 'Hay nuevo contenido disponible',
  'app.pwa.serviceworker.updated.hint': 'Por favor, haz clic en el botón "Actualizar" o actualiza la página manualmente',
  'app.pwa.serviceworker.updated.ok': 'Actualizar',
};
