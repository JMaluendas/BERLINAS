import { Link } from '@umijs/max';
import { Button, Result } from 'antd';

export default () => (
  <>
    <h1>Hola mundo...</h1>
  </>
);
